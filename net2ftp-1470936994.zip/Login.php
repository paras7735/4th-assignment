<?php 
error_reporting(0);
session_start();
if(isset($_SESSION['user'])!="")
{
 header("Location: proc.php");
}
if(isset($_POST['Submit'])){
$user=$_POST["Username"];
$pass=$_POST["Password"];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$res=mysql_query("SELECT * from u WHERE name='$user'and password='$pass'")
  or die("fuck off".mysql_error());
$row= mysql_fetch_array($res);
if ($row['name']==$user && $row['password']==$pass) {
	$_SESSION['user'] = $row['name'];
  header("Location: proc.php");
	echo "welcome ".$user;
} else { ?>
	<script type="text/javascript">alert('Id and Password are wrong or are not registered');</script>
	<?php
}
}
   


?>






<!DOCTYPE html>
<html>
<head>
	<title>Login</title><script type="text/javascript" src="processing.js"></script>
	<style type="text/css">
body{color: white;margin:0;padding:0;}
	a{color: white;}
#mysketch{position: absolute; top: 0px;width: 0px; height: 100vh;width: 100vw;margin: 0;padding: 0;z-index: -100;white-space: nowrap; overflow-x: hidden;
    overflow-y: hidden;}
		#form{margin: 10vmax;position: absolute;top: 5vmax;left:27.5vmax;background-color: rgba(0, 0, 0, 0.5);border-radius: 1vmax;width: 19.5vmax;height: 20vmax;font-family:Arial; box-shadow: 0vmax 0vmax .5vmax #888888;padding: 0;}
		#head{height: 2vmax;width: 10vmax;position: relative; left:1vmax;
	top: 1vmax;
margin: 0;
	font-size:1.5vmax;
	color: white;padding: 0;padding-left:7vmax; padding-top: .75vmax;padding-bottom: .5vmax;
	border-top-right-radius: 0.5vmax;
	border-top-left-radius: 0.5vmax;
}
canvas{margin:0;padding:0;}
		#Username{margin: 0;padding: 0;width: 15vmax;margin-top: 2vmax;margin-left: 1vmax;position: absolute;left: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	background-color: #e8ebed;top: 4vmax;
	color: #576366;padding-left: .5vmax;}
		#Password{margin: 0;padding: 0;width: 15vmax;margin: 1vmax;position: absolute;left: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;top: 9vmax;
	background-color: #e8ebed;
	color: #576366;padding-left: .5vmax;}
	#submit{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 6.25vmax;top: 14vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#submit:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}

#reg{margin: 0;padding: 0;position: absolute;top: 4vmax;left:8vmax;top:17.5vmax;font-size: 1vmax;}
form{margin: 0;padding: 0;width: 19.5vmax;height: 20vmax;}
body{margin: 0;padding: 0;}

	</style>

</head>
<body><div>Try Left And Right Clicking As Many Times In the Blank Spaces Of Pages For Different Effects (Not On This Page)</div><div id="mysketch"></div><canvas id="mysketch" data-processing-sources="lines.pde"/></canvas></div>
<div id="form">
<div id="head">Login</div>
	<form  method="POST">
<input type="text" id="Username" placeholder="Username" name="Username" required>
<input type="password" id="Password" placeholder="Password" name="Password" required>
<input type="Submit" id="submit" value="Submit" name="Submit">
<a id="reg" href="regis.php">Register</a>
</form>
</div>



</body>
</html>