<?php
error_reporting(0);
session_start();
if(isset($_SESSION['user'])!="")
{
 header("Location: proc.php");
}?>

<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title><script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js">
		
	</script><script type="text/javascript" src="processing.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<style type="text/css">
#mysketch{position: absolute; top: 0px;width: 0px; height: 150vh;width: 98vw;margin: 0;padding: 0;z-index: -100;white-space: nowrap; overflow-x: hidden;
    overflow-y: hidden;}
		#form{margin: 10vmax;margin-top: 5vmax;position: absolute;top: 0vmax;left:20.5vmax;background-color: rgba(99, 122, 145, 0.5);border-radius: 1vmax;width: 40vmax;height: 50vmax;font-family:Arial; box-shadow: 0vmax 0vmax .5vmax #888888;padding: 0;padding-left:1vmax;padding-top: 2vmax; color: white;font-size: 2vmax;line-height: 4.5vmax;}
		#head{height: 2vmax;width: 10vmax;position: relative; left:8vmax;
	top: -2vmax;
margin: 0;
	font-size:2.5vmax;
	color: white;padding: 0;padding-left:6vmax; padding-top: .75vmax;padding-bottom: .5vmax;
	border-top-right-radius: 0.5vmax;
	border-top-left-radius: 0.5vmax;
}#datepicker{margin: 0;padding: 0;width: 15vmax;margin-top: -1vmax;margin-left: 1vmax;position: absolute;right: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	top: 39vmax;
	color: #576366;padding-left: .5vmax;}

#gender{margin: 0;padding: 0;width: 15vmax;margin-top: 0vmax;margin-left: 1vmax;position: absolute;right: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	top: 32.5vmax;
	color: #576366;padding-left: .5vmax;}
#image{margin: 0;padding: 0;width: 15vmax;margin-top: 1vmax;margin-left: 1vmax;position: absolute;right: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	top: 29vmax;
	color: #576366;padding-left: .5vmax;}

#pass2{margin: 0;padding: 0;width: 15vmax;margin-top: 1vmax;margin-left: 1vmax;position: absolute;right: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	background-color: #e8ebed;top: 24vmax;
	color: #576366;padding-left: .5vmax;}
#email{margin: 0;padding: 0;width: 15vmax;margin-top: 1vmax;margin-left: 1vmax;position: absolute;right: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	background-color: #e8ebed;top: 14vmax;
	color: #576366;padding-left: .5vmax;}
#name{margin: 0;padding: 0;width: 15vmax;margin-top: 2vmax;margin-left: 1vmax;position: absolute;right: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	background-color: #e8ebed;top: 4vmax;
	color: #576366;padding-left: .5vmax;}
		#Username{margin: 0;padding: 0;width: 15vmax;margin-top: 1.5vmax;margin-left: 1vmax;position: absolute;right: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	background-color: #e8ebed;top: 9vmax;
	color: #576366;padding-left: .5vmax;}
		#Password{margin: 0;padding: 0;width: 15vmax;margin: 1vmax;position: absolute;right: 0vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;top: 19vmax;
	background-color: #e8ebed;
	color: #576366;padding-left: .5vmax;}
	#Submit{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 15vmax;top: 44vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
a{color: white}
	#message{position: absolute;left: 25vmax;font-size: 1vmax;top: 26.5vmax;}
#Submit:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}

#reg{margin: 0;padding: 0;position: absolute;top: 4vmax;left:17.25vmax;top:47.5vmax;font-size: 1vmax;}
form{margin: 0;padding: 0;width: 19.5vmax;height: 20vmax;}
body{margin: 0;padding: 0;}
		#ll{display: ;}
	</style>
</head>
<body><div id="mysketch"></div><canvas id="mysketch" data-processing-sources="reallines.pde"/></canvas></div>
<div id="form">
<div id="head">Register</div>
	<form method="POST" enctype="multipart/form-data">
Name:</br><input type="text" id="name" placeholder="Name" name="name" required>
Username:</br><input type="text" id="Username" Placeholder="Username" required pattern="\w+" name="Username" required>
Email:</br><input type="email" id="email" placeholder="email" name="email">
Password:</br><input type="password" id="Password" placeholder="Password" required pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d@#$%_-]{8,20}$" title="Password must contain at least 8 characters, including UPPER/lowercase and numbers and no space" value="" name="Password" required onchange="
  this.setCustomValidity(this.validity.patternMismatch ? this.title : '');
  if(this.checkValidity()) form.pwd2.pattern = this.value;
">
Re-enter Password:</br><input type="password" id="pass2" placeholder="Password" required pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d@#$%_-]{8,20}$" title="Please enter the same Password as above" value="" name="pass2" required onchange="
  this.setCustomValidity(this.validity.patternMismatch ? this.title : '');
">
<div id="message"></div>
Image:</br><input type="file" id="image" name="image">
Gender:</br><div id="gender">
  <input type="radio" name="Gender" checked="checked" value="Female" required>Female
  <input type="radio" name="Gender"  value="Male" required>Male
  <input type="radio" name="Gender"  value="Other" required>Other</div>
<script>
	$(function() {
		$( "#datepicker" ).datepicker();
	});
	</script>
	 Date Of Birth:</br><input type="text" placeholder="Date Of Birth" name="dob" id="datepicker" required>
	<script type="text/javascript">

$('#Password, #pass2').on('keyup', function () {
    if (document.getElementById("Password").value == document.getElementById("pass2").value && document.getElementById("pass2").value!=""&& document.getElementById("Password").value!="") {
        $('#message').html('Matching').css('color', 'green');
        $('#Submit').prop('disabled', false);
        
    } else if (document.getElementById("Password").value != document.getElementById("pass2").value&& document.getElementById("pass2").value!=""&& document.getElementById("Password").value!="") {
        $('#message').html('Not Matching').css('color', 'red');
        $('#Submit').prop('disabled', true);
        }
    else if (document.getElementById("Password").value =="" && document.getElementById("pass2").value==""){$('#message').html('empty').css('color', 'red');
        $('#Submit').prop('disabled', true);

};});
</script>
<input type="Submit" id="Submit" value="Submit" name="Submit"><div id="block"></div>
<a id="reg" href="Login.php">Back</a>
</form>
</div>
<div id="ll">
<?php 
//error_reporting(0);

if(isset($_POST['Submit'])){
$dob=$_POST["dob"];
$real=$_POST["name"];
$user=$_POST["Username"];
$pass=$_POST["Password"];
$email=$_POST["email"];
$gender=$_POST["Gender"];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
	$imageName = mysql_real_escape_string($_FILES["image"]["name"]);
	$imageData = mysql_real_escape_string(file_get_contents($_FILES["image"]["tmp_name"]));
	$imageType = mysql_real_escape_string($_FILES["image"]["type"]);

$qy = mysql_query("SELECT * FROM u WHERE name='$_POST[Username]'") or die(mysql_error()); 
if(!$row = mysql_fetch_array($qy) ) 
	{ $query ="INSERT INTO `u` (`id`, `name`, `password`, `gender`,`dob`,`realname`,`email`) VALUES (NULL,'$user','$pass','$gender','$dob','$real','$email')";

$data = mysql_query ($query)or die('cewqceqcvew'.mysql_error());
 if($data) { if(substr($imageType,0,5) == "image")
	{
		$res1=mysql_query("UPDATE `u` set `imgname`='$imageName'WHERE name= '$user'");
		$res2=mysql_query("UPDATE `u` set `image`='$imageData' WHERE name= '$user'");
		
	}
	else
	{
		?><script type="text/javascript">alert("File Uploaded is not an image/no image uploaded");
	
 </script><?php
	} ?><script type="text/javascript">alert("YOUR REGISTRATION IS COMPLETED...");
	window.location = "Login.php"
 </script>
 <?php 
}
 } 
 else { 
 	?><script type="text/javascript">alert("User Aldready Exists");
 	</script>
 	<?php 
 }


   
}

?></div>

</body>
</html>
