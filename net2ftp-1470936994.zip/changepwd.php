<?php
error_reporting(0);
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: Login.php");
}
else if($_SESSION['user']=='Admin'){header("Location: admin.php");}
$var=$_SESSION['user'];
if(isset($_POST['Change'])){
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$user=$_SESSION["user"];
$pass=$_POST["pass"];
$pass2=$_POST["pass2"];
$res=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
$row= mysql_fetch_array($res);
if ($row['name']==$user && $row['password']==$pass) {
	$res2=mysql_query("UPDATE `u` SET `password` = '$pass2' WHERE name= '$user'")
  or die("fuck off".mysql_error());
$row2= mysql_fetch_array($res2);
  header("Location: signup.php?logout");
} else { ?>
	<script type="text/javascript">alert('Password is wrong');</script><?php
}
}







$user=$_SESSION["user"];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$result=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
  $rower= mysql_fetch_array($result);

?>


<!DOCTYPE html>
<html >
<head>
<title>Welcome - <?php echo ''.$_SESSION['user']; ?></title><script type="text/javascript" src="processing.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js">
		
	</script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<style type="text/css">
#setting{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 47vmax;top: 36vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#setting:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#logout{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 37vmax;top: 36vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#logout:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#delete{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 17vmax;top: 15vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#delete:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
form{margin: 10vmax;position: absolute;top: 0vmax;left:20.5vmax;background-color: rgba(99, 122, 145, 0.5);border-radius: 1vmax;width: 32vmax;height: 15vmax;font-family:Arial; box-shadow: 0vmax 0vmax .5vmax #888888;padding: 0;color: white;font-size: 2vmax;padding: 0;padding-top: 5.5vmax;line-height: 4vmax;padding-left: 2vmax;}
#pass{margin: 0;padding: 0;width: 15vmax;margin-top: 2vmax;margin-left: 1vmax;position: absolute;left: 15vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	background-color: #e8ebed;top: 4vmax;
	color: #576366;padding-left: .5vmax;}
		#pass2{margin: 0;padding: 0;width: 15vmax;margin: 1vmax;position: absolute;left: 15vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;top: 9vmax;
	background-color: #e8ebed;
	color: #576366;padding-left: .5vmax;}
#mysketch{position: absolute; top: 0px;width: 0px; height: 99.2vh;width: 99.2vw;margin: 0;padding: 0;z-index: -100;white-space: nowrap; overflow-x: hidden;
    overflow-y: hidden;}

</style>
</head>
<body><div id="mysketch"></div><canvas id="mysketch" data-processing-sources="lines13.pde"></canvas></div>
<div id="header">
 
    
         Hi <?php echo ''.$rower['realname']; ?><a id="logout" href="signup.php?logout">Sign Out</a><a id="setting" href="settings.php">Back</a>
</br></br></br></br></br></br>

<form  method="POST">
Old Password:<input type="password" id="pass" placeholder="Password" required pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d@#$%_-]{8,20}$" title="Password must contain at least 8 characters, including UPPER/lowercase and numbers and no space" value="" name="pass" required onchange="
  this.setCustomValidity(this.validity.patternMismatch ? this.title : '');
  
"></br>
New Password<input type="password" id="pass2" placeholder="Password" required pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d@#$%_-]{8,20}$" title="Password must contain at least 8 characters, including UPPER/lowercase and numbers and no space" value="" name="pass2" required onchange="
  this.setCustomValidity(this.validity.patternMismatch ? this.title : '');
"></br>

 <input type="Submit" id="delete" value="Change Password" name="Change">
</form>
<img src="">
       
</div>
</body>
</html>