<?php
error_reporting(0);
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: Login.php");
}
else if($_SESSION['user']=='Admin'){header("Location: admin.php");}
$var=$_SESSION['user'];
$user=$_SESSION['user'];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$result=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
  $rower= mysql_fetch_array($result);
$proff=$rower['id'];
$result2=mysql_query("SELECT * from std WHERE proff='$proff'")
  or die("fuck off".mysql_error());
  










 if(isset($_POST['delete'])){

$name24=$_POST['input2'];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$resl=mysql_query("DELETE FROM `std` WHERE rollnumber='$name24' and proff='$proff' ");
$rowl=mysql_fetch_array($resl);
header("Location: student.php");
echo $name24;};

/*if(isset($_POST['edit'])){

$name=$_POST['input2'];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$resl=mysql_query("UPDATE `std` SET `namestd` = 'kk' WHERE proff = '$proff' and namestd='$name'");
$rowl=mysql_fetch_array($resl);
};
*/










if(isset($_POST['submit'])){ 
$name2=$_POST['name'];
$roll=$_POST['roll'];
$qy = mysql_query("SELECT * FROM std WHERE proff='$proff' and rollnumber='$roll'") or die(mysql_error()); 
if(!$row = mysql_fetch_array($qy) ) 
  { $query ="INSERT INTO `std` (`id`, `namestd`, `rollnumber`, `proff`) VALUES (NULL,'$name2','$roll','$proff')";

$data = mysql_query ($query)or die('cewqceqcvew'.mysql_error());
 if($data) {
  ?><script type="text/javascript">alert("YOUR REGISTRATION IS COMPLETED...");
  window.location = "student.php"
 </script>
 <?php 
}
 } 
 else { 
  ?><script type="text/javascript">alert("Roll Number Aldready Exists");
  </script>
  <?php }}
  ?>
  <!DOCTYPE html>
  <html>
  <head>
  	<title>Welcome - <?php echo ''.$_SESSION['user']; ?></title>
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style type="text/css">
  #hid{ position: absolute; background-color: rgba(0,0,0,0.5);width: 100vw;height: 100vh;z-index:1;top: 100vmax;color: white;font-size: 2vmax;}    
#hid2{ position: absolute; background-color: rgba(0,0,0,0.5);width: 100vw;height: 100vh;z-index:1;top: 100vmax;color: white;font-size: 2vmax;}    
body{overflow:hidden;}
#ll,#mm{position: absolute;top: 40vh;left: 40vw;}
input{color: black;}


  </style>
   <script type="text/javascript">$(document).ready(function(){
    $(".ed").click(function() {
  $("#hid").animate({top: "0vmax"},1000);
  var nme=$(this).attr("name");
  
  document.getElementById("name2").placeholder = nme;

 
 
});
    $(".ed2").click(function() {
  $("#hid2").animate({top: "0vmax"},1000);
  var rll=$(this).attr("name");
  document.getElementById("name3").placeholder = rll;
  document.getElementById("roll3").placeholder = rll;
 
 
});

$("#h1").click(function() {
  $("#hid").animate({top: "100vmax"},2);
  
 
 
});
$("#h2").click(function() {
  $("#hid2").animate({top: "100vmax"},2);
  
 
 
});
 $("#submit2").click(function() {
  var nme2=$('#name2').attr("placeholder");
  
  var nnme=$('#name2').val();
 

 $.ajax({url: "demo.php", type: 'POST',
                     data: {name2:nme2,newname2:nnme}, success: function(success){alert("Value Changed");
       
    }});
window.location = "student.php";
});

$("#submit3").click(function() {
  var nme2=$('#name3').attr("placeholder");
  
  var nnme=$('#name3').val();
 

 $.ajax({url: "demo.php", type: 'POST',
                     data: {name3:nme2,newname3:nnme}, success: function(success){alert("Value Changed");
       
    }});
window.location = "student.php";
});








});</script>
</head>
  <body><div id="hid"><form id="ll" method="POST">
  Edit STUDENT <BR>
  New Name:<input type="text" name='name2' id="name2" required><BR>
  <input type="submit" name="submit2" id="submit2" class="btn btn-primary"> <button id="h1" class="btn btn-primary">Close</button>
 </form></div>
 <div id="hid2"><form id="mm" method="POST">
  Edit STUDENT <BR>
  New RollNumber: <input type="text" name='name3' id="name3" required><BR>
  <input type="submit" name="submit3" class="btn btn-primary" id="submit3"> <button id="h2" class="btn btn-primary">Close</button>
 </form></div> <div class="table">
  <table class="table table-responsive">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Roll Number</th>
        <th>Delete/Edit Name/Edit Roll Number</th>
      </tr>
    </thead>
    <tbody>
      
  
  <?php 
$i=1;
  while($rower2= mysql_fetch_array($result2)) {

        echo "<tr><td>" .$i. "</td><td>" . $rower2["namestd"]. "</td><td>" . $rower2["rollnumber"].  " </td><td>"?><form method="POST"><input type="hidden" name="input2" value='<?php echo $rower2['rollnumber']?>' ><input id='del' name='delete' type="submit" class="btn btn-primary" value='Delete <?php echo $rower2["namestd"] ?>' >    <input class='ed' name="<?php echo $rower2['namestd']?>" type="button"  value='Edit Name of <?php echo $rower2["namestd"] ?>' > <input class='ed2' name="<?php echo $rower2['rollnumber']?>" type="button"  value='Edit Roll Number of <?php echo $rower2["namestd"] ?>'></td></BR></tr>  </form><?php $i++;
        
    };?>

 
 </tbody>
 </table>
 <form method="POST">
 	ADD STUDENT <BR>
 	Name:<input type="text" name='name' required><BR>

 	Roll Number:<input type="text" name='roll' required><BR>
 	<input type="submit" class="btn btn-primary"  name="submit">
 </form></BR>
 <a href='proc.php' class="btn btn-primary" >Back</a>
 </br>
      If Values dont change on editing refresh page  


  </body>
  </html>