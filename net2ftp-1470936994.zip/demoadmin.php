<?php
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: Login.php");
}
else if($_SESSION['user']!='Admin'){header("Location: proc.php");}
$var=$_SESSION['user'];
$user=$_COOKIE['var'];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$result=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
  $rower= mysql_fetch_array($result);
$proff=$rower['id'];
$result2=mysql_query("SELECT * from std WHERE proff='$proff'")
  or die("fuck off".mysql_error());

if(isset($_POST['name2']))
{
$name2=$_POST['name2'];

$newname2=$_POST['newname2'];



$res=mysql_query("UPDATE `std` SET `namestd` = '$newname2' WHERE proff='$proff' and namestd= '$name2'")
  or die("fuck off".mysql_error());
$row= mysql_fetch_array($res);
echo $newname2;
}
if(isset($_POST['name3']))
{
$name3=$_POST['name3'];

$newname3=$_POST['newname3'];

$qy = mysql_query("SELECT * FROM std WHERE proff='$proff' and rollnumber='$newname3'") or die(mysql_error()); 
if(!$row = mysql_fetch_array($qy) ) 
  { $query ="UPDATE `std` SET `rollnumber` = '$newname3' WHERE proff='$proff' and rollnumber= '$name3'";

$data = mysql_query ($query)or die('cewqceqcvew'.mysql_error());
 if($data) {header("Location: student_admin.php");
  ?>Values Changed
 <?php 
}
 } 
 else { header("Location: student_admin.php");
  ?>Roll Number Aldready Exists
  <?php }}
  ?>
