<?php
error_reporting(0);
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: Login.php");
}
else if($_SESSION['user']=='Admin'){header("Location: admin.php");}
$var=$_SESSION['user'];
$user=$_SESSION['user'];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$result=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
  $rower= mysql_fetch_array($result);

?>
<!DOCTYPE html>
<html >
<head>
<title>Welcome - <?php echo ''.$_SESSION['user']; ?></title><script type="text/javascript" src="processing.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style type="text/css">#ll{height:10vmax;width:10vmax;position: absolute;top: 2vmax;left: 88vmax;}
#details{background-color: rgba(99, 122, 145, 0.5);color: white;width: 30vmax;height: 20vmax;padding: 0;padding-top: 2vmax;padding-left: 2vmax;position: absolute;top: 15vmax;left:30vmax;font-size: 2vmax;  box-shadow: 0vmax 0vmax .5vmax #888888;}
#mysketch{position: absolute; top: 0px;width: 0px; height: 99.2vh;width: 99.2vw;margin: 0;padding: 0;z-index: -100;white-space: nowrap; overflow-x: hidden;
    overflow-y: hidden;}
#setting{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 47vmax;top: 36vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#setting:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#logout{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 37vmax;top: 36vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#logout:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#header{font-size: 4vmax;font-family: Arial;}

#std{position:absolute;left:22vmax;top:20vmax;}
</style>
</head>
<body><div id="mysketch"></div><canvas id="mysketch" data-processing-sources="cball13.pde"></canvas></div>
<?php
echo '<img id="ll" src="data:image/jpg;base64,'.base64_encode( $rower['image'] ).'"/>';?>
<div id="header">
 
    
         Hi <?php echo ''.$rower['realname']; ?></div><a id="logout" href="signup.php?logout">Sign Out</a><a id="setting" href="settings.php">Settings</a>
       <div id="details" >
       Details</br>
	Name: <?php echo "".$rower['realname'];?></br>

	Username: <?php echo "".$rower['name'];?></br>Email:<?php echo "".$rower['email'];?></br>
	Gender: <?php echo "".$rower['gender'];?></br>
	Date of Birth: <?php echo "".$rower['dob'];?></br>
</div>
<div id="std"><a id="std" class="btn btn-primary" href="student.php">Students</a></div>
</body>
</html>