<?php
error_reporting(0);
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: Login.php");
}
else if($_SESSION['user']=='Admin'){header("Location: admin.php");}
$var=$_SESSION['user'];
$user=$_SESSION['user'];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$result=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
  $rower= mysql_fetch_array($result);
if(isset($_POST['delete'])){
$user=$_SESSION["user"];
$pass=$_POST["Password"];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$res=mysql_query("DELETE FROM `u` WHERE name='$user'")
  or die("fuck off".mysql_error());
$row= mysql_fetch_array($res);
header("Location: signup.php?logout");
}
?>
<!DOCTYPE html>
<html >
<head><script type="text/javascript" src="processing.js"></script>
<title>Welcome - <?php echo ''.$_SESSION['user']; ?></title><style type="text/css">#header{font-size: 4vmax;font-family: Arial;}
#setting{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 53vmax;top: 26vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#mysketch{position: absolute; top: 0px;width: 0px; height: 99.2vh;width: 99.2vw;margin: 0;padding: 0;z-index: -100;white-space: nowrap; overflow-x: hidden;
    overflow-y: hidden;}
#setting:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#logout{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 32vmax;top: 26vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#logout:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#chg{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 47vmax;top: 16vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#chg:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#delete{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 41vmax;top: 26vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#delete:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#pwd{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 33vmax;top: 16vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#pwd:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
</style>
</head>
<body><div id="mysketch"></div><canvas id="mysketch" data-processing-sources="lines13reg.pde"></canvas></div>
<div id="header">
 
    
         Hi <?php echo ''.$rower['realname']; ?></div><a id="logout" href="signup.php?logout">Sign Out</a><a id="setting" href="proc.php">Back</a>

<a id="chg" href="change.php">Change Details</a></br>
<a id="pwd" href="changepwd.php">Change Password</a></br>
<form  method="POST">
<input type="Submit" id="delete" value="Delete Account" name="delete">
</form>
       
</div>
</body>
</html>