<?php
error_reporting(0);
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: Login.php");
}
else if($_SESSION['user']!='Admin'){header("Location: proc.php");}
$var=$_SESSION['user'];
$user=$_SESSION['user'];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$result=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
  $rower= mysql_fetch_array($result);
$proff=$rower['id'];
$result2=mysql_query("SELECT * from u ")
  or die("fuck off".mysql_error());
  











  ?>
  <?php if(isset($_POST['delete'])){ 

$name=$_POST['varname'];

setcookie('var',$name,time() + (86400 * 7),"/");


header("Location: student_admin.php");};

  ?>
  <!DOCTYPE html>
  <html>
  <head>
  	<title>Welcome - <?php echo ''.$_SESSION['user']; ?></title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  </head>
  <body>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        
      </tr>
    </thead>
    <tbody>
  <form method="POST">
  <?php 
$i=1;
  while($rower2= mysql_fetch_array($result2)) {
if($rower2["name"]!='Admin'){
echo '<tr><td>'.$i.'</td><td>'?><form method="POST"> <input type="hidden" name="varname" value="<?php echo $rower2["name"];?> ">
    <input type="submit" class="btn btn-primary" name="delete" value="<?php echo $rower2["realname"];?>">
</form></td></tr><?php ; $i++;}
        
    };?>

 </form>
 </tbody>
</table>
 
 <a class="btn btn-primary" href='proc.php'>Back</a>






  </body>
  </html>