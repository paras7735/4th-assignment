<?php
error_reporting(0);
session_start();
if(!isset($_SESSION['user']))
{
 header("Location: Login.php");
}
else if($_SESSION['user']=='Admin'){header("Location: admin.php");}
$var=$_SESSION['user'];
if(isset($_POST['Change'])){
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$user=$_SESSION["user"];
$pass=$_POST["Username"];
$res=mysql_query("UPDATE `u` SET `name` = '$pass' WHERE name= '$user'")
  or die("fuck off".mysql_error());
$row= mysql_fetch_array($res);
$pass2=$_POST["name"];
$res2=mysql_query("UPDATE `u` SET `realname` = '$pass2' WHERE name= '$user'")
  or die("fuck off".mysql_error());
$row2= mysql_fetch_array($res2);
$pass3=$_POST["Gender"];
$res3=mysql_query("UPDATE `u` SET `gender` = '$pass3' WHERE name= '$user'")
  or die("fuck off".mysql_error());
$row3= mysql_fetch_array($res3);
$pass4=$_POST["dob"];
$res4=mysql_query("UPDATE `u` SET `dob` = '$pass4' WHERE name= '$user'")
  or die("fuck off".mysql_error());
$row4= mysql_fetch_array($res4);
header("Location: signup.php?logout");
}
$user=$_SESSION["user"];
mysql_connect("localhost","u243964871_login","pwd3433");
mysql_select_db("u243964871_login");
$result=mysql_query("SELECT * from u WHERE name='$user'")
  or die("fuck off".mysql_error());
  $rower= mysql_fetch_array($result);


?>


<!DOCTYPE html>
<html >
<head>
<title>Welcome - <?php echo ''.$_SESSION['user']; ?></title><script type="text/javascript" src="processing.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js">
		
	</script>
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script><style type="text/css">#header{font-size: 4vmax;font-family: Arial;height:1vmax;width:1vmax;}
#setting{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 47vmax;top: 36vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#setting:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#logout{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 37vmax;top: 36vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#logout:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
#name,#Username,#datepicker{margin: 0;padding: 0;width: 15vmax;margin-top: 1vmax;margin-left: 1vmax;height: 2.5vmax;border-radius:0.5vmax;border-width: 0vmax;font-size: 1vmax;
	background-color: #e8ebed;
	color: #576366;padding-left: .5vmax;}
#delete{margin: 0;padding: 0;border: 0;border-radius:0.5vmax; position: absolute;left: 14vmax;top: 22vmax;
	background-color:#6d7d9c;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:1vmax;
	padding:1vmax 2vmax;
	text-decoration:none;
	text-shadow:0px .1vmax 0px #2f6627;
	  transition-duration: 0.3s;
  
  transition-property: box-shadow, transform,background-color;

}
#delete:hover {
	background-color:#5d6096;
transform: scale(1.1);
	 box-shadow: 0 0.1vmax 0.1vmax -0.1vmax rgba(0, 0, 0, 0.5);
  
}
form{margin: 5vmax;position: absolute;top: 0vmax;left:25.5vmax;background-color: rgba(99, 122, 145, 0.5);border-radius: 1vmax;width: 32vmax;height: 25vmax;font-family:Arial; box-shadow: 0vmax 0vmax .5vmax #888888;padding: 0;color: white;font-size: 2vmax;padding: 0;padding-top: 1.5vmax;line-height: 4vmax;padding-left: 2vmax;}
#mysketch{position: absolute; top: 0px;width: 0px; height: 99.2vh;width: 99.2vw;margin: 0;padding: 0;z-index: -100;white-space: nowrap; overflow-x: hidden;
    overflow-y: hidden;}	

</style>
</head>
<body><div id="mysketch"></div><canvas id="mysketch" data-processing-sources="cball133.pde"></canvas></div>
<div id="header">
 
    
         Hi <?php echo ''.$rower['realname']; ?></div>&nbsp;<a id="logout" href="signup.php?logout">Sign Out</a>&nbsp;<a id="setting" href="settings.php">Back</a>
</br></br></br></br></br></br>

<form  method="POST">
Name:<input type="text" id="name" value="<?php echo "".$rower['realname'];?>" name="name" required></br>
Username:<input type="text" id="Username" value="<?php echo "".$user;?>" required pattern="\w+" name="Username" required></br>
 Gender:
  <input type="radio" name="Gender" <?php if ($rower['gender']=="Female"){?> checked="checked" <?php };?>value="Female">Female
  <input type="radio" name="Gender" <?php if ($rower['gender']=="Male"){?> checked="checked" <?php };?>value="Male">Male
<script>
	$(function() {
		$( "#datepicker" ).datepicker();
	});
	</script>
	<p>Date of Birth: <input type="text" name="dob" id="datepicker" value="<?php echo "".$rower['dob'];?>" required ></p>
<input type="Submit" id="delete" value="Change Account" name="Change">
</form>
<img src="">
       
</div>
</body>
</html>